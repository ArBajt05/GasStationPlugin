﻿using Rocket.API;
using Rocket.Unturned.Chat;
using Rocket.Unturned.Player;
using SDG.Unturned;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;
using UnityEngine;

namespace GasStationSystem
{
    public class GasStationSystemZoneCreateCommand : IRocketCommand
    {
        public AllowedCaller AllowedCaller
        {
            get
            {
                return AllowedCaller.Player;
            }
        }

        public List<string> Permissions
        {
            get
            {
                return new List<string>() {
                    "Tankuj.zone"
                };
            }
        }
        public bool RunFromConsole
        {
            get { return false; }
        }

        public string Name
        {
            get { return "tankujzone"; }
        }
        public string Syntax
        {
            get
            {
                return "/tankujzone";
            }
        }
        public string Help
        {
            get { return "Wpisz /tankujzone aby utworzyć strefe w której gracze będą mogli zatankować auto"; }
        }
        public List<string> Aliases
        {
            get { return new List<string> { "tankujzone" }; }
        }

        private static Class1 Plugin => Class1.Instance;
        private static Configuration Config => Plugin.Configuration.Instance;
        //tankujzone add 
        public void Execute(IRocketPlayer caller, params string[] command)
        {
            var player = (UnturnedPlayer)caller;

            if (command.Length == 0)
            {
                UnturnedChat.Say(player, Plugin.Translate("hs_usage"));
                return;
            }

            if (command[0].ToLower() == "add")
            {
                if (Config.FillFuelZones.Any(s => Vector3.Distance(s.Position, player.Position) <= Config.ZoneRadius * 2))
                {
                    UnturnedChat.Say(player, Plugin.Translate("hs_too_close"));
                    return;
                }

                var station = new Zone(player.Position);

                if (command.Length > 1)
                {
                    if (!Config.UseUconomy)
                    {
                        UnturnedChat.Say(player, Plugin.Translate("hs_uconomy_disabled"));
                        return;
                    }
                    if (!decimal.TryParse(command[1], out var cost))
                    {
                        UnturnedChat.Say(player, Plugin.Translate("hs_wrong_cost"));
                        return;
                    }

                    station = new Zone(player.Position, true, cost);
                    Config.FillFuelZones.Add(station);
                    Plugin.Configuration.Save();

                    UnturnedChat.Say(player, Plugin.Translate("hs_added_pay", cost, Config.FillFuelZones.IndexOf(station)));
                    return;
                }

                Config.FillFuelZones.Add(station);
                Plugin.Configuration.Save();

                UnturnedChat.Say(player, Plugin.Translate("hs_added", Config.FillFuelZones.IndexOf(station)));
                return;
            }
            if (command[0].ToLower() == "remove")
            {
                if (Config.FillFuelZones.Count == 0)
                {
                    UnturnedChat.Say(player, Plugin.Translate("hs_no_stations_exist"));
                    return;
                }

                if (command.Length > 1)
                {
                    if (!int.TryParse(command[1], out var index) || (Config.FillFuelZones.Count - 1 < index || index < 0))
                    {
                        UnturnedChat.Say(player, Plugin.Translate("hs_wrong_id"));
                        return;
                    }

                    Config.FillFuelZones.RemoveAt(index);
                    Plugin.Configuration.Save();

                    UnturnedChat.Say(player, Plugin.Translate("hs_removed"));
                    return;
                }

                var station = Config.FillFuelZones.FirstOrDefault(s =>
                    Vector3.Distance(player.Position, s.Position) <= Config.ZoneRadius);

                if (station == null)
                {
                    UnturnedChat.Say(player, Plugin.Translate("hs_not_in"));
                    return;
                }

                Config.FillFuelZones.Remove(station);
                Plugin.Configuration.Save();

                UnturnedChat.Say(player, Plugin.Translate("hs_removed"));
                return;
            }
            if (command[0].ToLower() == "move")
            {
                if (command.Length < 2 || !int.TryParse(command[1], out var index) || (Config.FillFuelZones.Count - 1 < index || index < 0))
                {
                    UnturnedChat.Say(player, Plugin.Translate("hs_wrong_id"));
                    return;
                }

                Config.FillFuelZones[index].X = player.Position.x;
                Config.FillFuelZones[index].Y = player.Position.y;
                Config.FillFuelZones[index].Z = player.Position.z;
                Plugin.Configuration.Save();

                UnturnedChat.Say(player, Plugin.Translate("hs_moved"));
                return;
            }
            if (command[0].ToLower() == "id")
            {
                var station = Config.FillFuelZones.FirstOrDefault(s =>
                    Vector3.Distance(player.Position, s.Position) <= Config.ZoneRadius);

                if (station == null)
                {
                    UnturnedChat.Say(player, Plugin.Translate("hs_not_in"));
                    return;
                }

                UnturnedChat.Say(player, Plugin.Translate("hs_index", Config.FillFuelZones.IndexOf(station)));
                return;
            }
            if (command[0].ToLower() == "amount")
            {
                UnturnedChat.Say(player, Plugin.Translate("hs_amount", Config.FillFuelZones.Count));
                return;
            }
            if (command[0].ToLower() == "tp")
            {
                if (command.Length < 2 || !int.TryParse(command[1], out var index) || (Config.FillFuelZones.Count - 1 < index || index < 0))
                {
                    UnturnedChat.Say(player, Plugin.Translate("hs_wrong_id"));
                    return;
                }

                player.Teleport(Config.FillFuelZones[index].Position, player.Rotation);
                return;
            }

            UnturnedChat.Say(player, Plugin.Translate("hs_usage"));
        }
    }
}
