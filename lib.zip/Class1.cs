﻿using Rocket.API.Collections;
using Rocket.Core.Plugins;
using Rocket.Unturned.Chat;
using Rocket.Unturned.Events;
using Rocket.Unturned.Player;
using Steamworks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;
using UnityEngine;
using System.Security.Policy;

namespace GasStationSystem
{
    public class Class1 : RocketPlugin<Configuration>
    {
        public static Class1 Instance;
        private Dictionary<CSteamID, Zone> _playersInZones;

        protected override void Load()
        {
            Instance = this;
            _playersInZones = new Dictionary<CSteamID, Zone>();
            UnturnedPlayerEvents.OnPlayerUpdatePosition += UnturnedPlayerEvents_OnPlayerUpdatePosition;
        }

        protected override void Unload()
        {
            UnturnedPlayerEvents.OnPlayerUpdatePosition -= UnturnedPlayerEvents_OnPlayerUpdatePosition;
        }

        public void UnturnedPlayerEvents_OnPlayerUpdatePosition(UnturnedPlayer player, Vector3 position)
        {
            var station = Configuration.Instance.FillFuelZones.FirstOrDefault(s => Vector3.Distance(position, s.Position) <= Configuration.Instance.ZoneRadius);

            if (station == null) return;

            if (!_playersInZones.ContainsKey(player.CSteamID) || _playersInZones[player.CSteamID] == null || _playersInZones[player.CSteamID] != station)
            {
                UnturnedChat.Say(player, station.Paid && Configuration.Instance.UseUconomy ? Translate("station_welcome_pay", station.Cost, fr34kyn01535.Uconomy.Uconomy.Instance.Configuration.Instance.MoneyName) : Translate("station_welcome"));
            }

            _playersInZones[player.CSteamID] = station;
        }

        public override TranslationList DefaultTranslations => new TranslationList
        {
                {"station_welcome","Welcome to health station! Would you like to be healed? (Type /yes to agree)"},
                {"station_welcome_pay","Welcome to Health Station! Would you like to be healed for {0} {1}? (Type /yes to agree)"},
                {"hs_usage","Use: /hs add/remove/move/id/tp/amount"},
                {"hs_ucon_false","Uconomy is disabled"},
                {"hs_added","Station added! Id: {0}"},
                {"hs_added_pay","Station with cost {0} added! Id: {1}"},
                {"hs_wrong_cost","Wrong cost"},
                {"hs_too_close","You are too close to existing station"},
                {"hs_no_stations_exist","There are no stations"},
                {"hs_wrong_id","Wrong id"},
                {"hs_removed","Station removed"},
                {"hs_not_in","You are not at station"},
                {"hs_moved","Station moved"},
                {"hs_id","Id: {0}"},
                {"hs_amount","Amount of stations: {0}"},
                {"yes_not_money","You don't have enough money to pay for healing"},
                {"yes_healed","You were healed!"}
            };
    }
}
